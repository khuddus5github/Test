package com.pardot.interview;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class TestClass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver;
		
	System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		
		driver=new ChromeDriver();
		
		
		
		
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		//Thread.sleep(500);
		
		login_pardot(driver,"pardot.applicant@pardot.com", "Applicant2012");
		CreateList(driver,"TestPurpose18");
		CreateList(driver,"TestPurpose18");
		UpdateList(driver, "TestPurpose18","TestPurpose19");
		CreateList(driver,"TestPurpose18");
		
		createprospect(driver,"s1@test.com","TestPurpose17");
		
		sendemail(driver);
		
		driver.close();
		driver.quit();
		

	}
	
	public static void login_pardot(WebDriver driver,String username, String password)
	{
		driver.manage().window().maximize();
		driver.get("https://pi.pardot.com/");
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.name("email_address")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("commit")).click();
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		if(driver.findElements(By.className("icon-magic")).size()!=0)
		{
			System.out.println("Login done successfully");
		}
		else
		{
			System.out.println("login not successful");
			System.exit(0);
		}
		
	}
	
	public static void CreateList(WebDriver driver,String ListName) throws InterruptedException
	{
		
		Thread.sleep(200);
		driver.findElement(By.className("icon-magic")).click();
		
		
		
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		driver.findElement(By.cssSelector("a[href*='segmentation']")).click();
		Thread.sleep(500);
		
		driver.findElement(By.className("icon-plus")).click();
		
		driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
		
		driver.findElement(By.name("name")).sendKeys(ListName);
		driver.findElement(By.id("save_information")).click();
		
		
		if (driver.findElements(By.xpath("//span[@class='help-inline'][contains(text(),'Please input a unique value for this field')]")).size()!=0)
		{
			System.out.println("Error Message due to duplicate list name");
			driver.findElement(By.linkText("Cancel")).click();
		}
		else
		{
			Thread.sleep(100);
			
			driver.findElement(By.className("icon-magic")).click();
			
			Thread.sleep(1000);
			
			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			
			driver.findElement(By.cssSelector("a[href*='segmentation']")).click();
			Thread.sleep(500);
			
			
			if (driver.findElements(By.linkText(ListName)).size()!=0)
			{
				System.out.println("Created Item present");
				
			}
			else
			{
				System.out.println("No such Item present");
			}
		}
		
		
		
		
		
	}
	
	public static void UpdateList(WebDriver driver, String ListName, String Newlistname) throws InterruptedException
	{
		driver.findElement(By.className("icon-magic")).click();
		
		Thread.sleep(200);
		
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		driver.findElement(By.cssSelector("a[href*='segmentation']")).click();
		Thread.sleep(500);
		if (driver.findElements(By.linkText(ListName)).size()!=0)
		{
			System.out.println("Item present");
			driver.findElement(By.linkText(ListName)).click();
			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			driver.findElement(By.linkText("Edit")).click();
			driver.findElement(By.name("name")).sendKeys("");
			driver.findElement(By.name("name")).sendKeys(Newlistname);
			driver.findElement(By.id("save_information")).click();
			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			
		
			
			driver.findElement(By.className("icon-magic")).click();
			
			Thread.sleep(1000);
			
			driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
			
			driver.findElement(By.cssSelector("a[href*='segmentation']")).click();
			Thread.sleep(500);
			
			
			if (driver.findElements(By.linkText(ListName)).size()!=0)
			{
				System.out.println("Created Item present");
				
			}
			else
			{
				System.out.println("No such Item present");
			}
			
			
			
		}
		else
		{
			System.out.println("No such Item present");
		}
	}
	
	public static void createprospect(WebDriver driver,String prospectname,String ListName) throws InterruptedException
	{
		
		Thread.sleep(200);
		/*driver.findElement(By.className("icon-group")).click();
		//driver.findElement(By.xpath("//span[contains(text(),'Prospects')]")).click();
		
		Thread.sleep(100);
		driver.findElement(By.linkText("Prospect List")).click();
		Thread.sleep(200);*/
		driver.navigate().to("https://pi.pardot.com/prospect");
		
		driver.findElement(By.className("icon-plus")).click();
		driver.findElement(By.name("email")).sendKeys(prospectname);
		
		Select select=new Select(driver.findElement(By.name("campaign_id")));
		select.selectByIndex(1);
		
		select=new Select(driver.findElement(By.name("profile_id")));
		select.selectByIndex(1);
		
		driver.findElement(By.id("toggle-inputs-lists-")).click();
		
		driver.findElement(By.xpath("//span[contains(text(),'Select a list to add...')]")).click();
		//driver.findElement(By.tagName("input")).sendKeys(ListName);
		driver.findElement(By.xpath("//input[@style='width: 263px;']")).sendKeys(ListName);
		//driver.findElement(By.xpath("//div[contains(@class, 'chzn-search')")).sendKeys(ListName);
		
		driver.findElement(By.xpath("//li[contains(text(),'"+ ListName+"')]")).click();
		driver.findElement(By.name("commit")).click();
		Thread.sleep(100);
		driver.findElement(By.className("icon-group")).click();
		
		Thread.sleep(200);
		driver.findElement(By.linkText("Prospect List")).click();
		Thread.sleep(500);
		
		driver.findElement(By.id("prospect_table_filter")).sendKeys(prospectname);
		
		if (driver.findElements(By.linkText(prospectname)).size()!=0)
		{
			System.out.println("Prospect created in system");
		}
		else
		{
			System.out.println("Prospect not created");
		}
	
		
	}
	
	public static void sendemail(WebDriver driver)
	{
		driver.navigate().to("https://pi.pardot.com/email/draft/edit");
		driver.findElement(By.name("name")).sendKeys("TestEmails");
		driver.findElement(By.xpath("//span[@class='input-xlarge uneditable-input object-name']")).click();
		
		driver.findElement(By.id("ember562")).sendKeys("Adil Yellow Jackets");
		driver.findElement(By.id("ember562")).sendKeys(Keys.ARROW_DOWN);
		//driver.findElement(By.xpath("//i[contains(text(),'Adil')]")).click();
		driver.findElement(By.id("select-asset")).click();
		
		WebElement rdbtn=driver.findElement(By.id("email_type_text_only"));
		
		rdbtn.click();
		
		driver.findElement(By.linkText("Save")).click();
	}

}
